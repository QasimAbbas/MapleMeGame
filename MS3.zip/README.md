# MapleMeGame
A simple game made with Java with MapleMe sprites
